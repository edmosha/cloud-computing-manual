import React, { useEffect } from 'react'
import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import { MenuBar } from 'widgets/editor/ui/menu-bar.tsx'
import { Button } from 'shared/ui'
// import Highlight from '@tiptap/extension-highlight'
// import TaskItem from '@tiptap/extension-task-item'
// import TaskList from '@tiptap/extension-task-list'


// define your extension array
const extensions = [
  StarterKit,
  // Highlight,
  // TaskList,
  // TaskItem,
]

const content = '<h2>Заголовок</h2>'

export const Editor = () => {

  const editor = useEditor({
    extensions,
    content,
    editorProps: {
      attributes: {
        class: 'py-5 px-3 focus:outline-none min-h-[60vh]',
      },
    },
  })

  return (
    <div>
      <div className={'my-5 border-2 rounded-lg'}>
        {editor && <MenuBar editor={editor} />}
        <EditorContent editor={editor} />
      </div>
      <Button onClick={() => console.log(editor?.getJSON())}>SaveJSON</Button>
    </div>

  )
}