import React, { ReactNode } from 'react'

export type Item = {
  icon: ReactNode
  title: string
  action: () => void
  isActive?: (() => boolean) | null
}

export const MenuItem = ({icon, title, action, isActive = null}: Item) => {
  return (
    <button
      className={`menu-item${isActive && isActive() ? ' is-active' : ''}`}
      onClick={action}
      title={title}
    >
      {icon}
    </button>
  )
}